<?php

namespace App\Filament\Resources\IsiMateriResource\Pages;

use App\Filament\Resources\IsiMateriResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateIsiMateri extends CreateRecord
{
    protected static string $resource = IsiMateriResource::class;
}
