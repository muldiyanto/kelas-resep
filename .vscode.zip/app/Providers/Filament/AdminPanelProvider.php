<?php

namespace App\Providers\Filament;

// namespace App\Filament\Pages\Auth;

use Filament\Pages;
use Filament\Panel;
use App\Models\Team;
use Filament\Widgets;
use Filament\PanelProvider;

use Filament\Facades\Filament;
use App\Filament\Pages\Settings;
use Filament\Navigation\MenuItem;
use Filament\Support\Colors\Color;
use Filament\Navigation\UserMenuItem;
use App\Filament\Resources\UserResource;

use Filament\Http\Middleware\Authenticate;
use App\Filament\Pages\Tenancy\RegisterTeam;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\AuthenticateSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;


use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;

class AdminPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->default()
            ->sidebarFullyCollapsibleOnDesktop(true)
            ->id('admin')
            ->path('admin')
            ->login()
                        ->registration()
                        ->passwordReset()
            ->colors([
                'primary' => Color::Blue,
            ])
            ->discoverResources(in: app_path('Filament/Resources'), for: 'App\\Filament\\Resources')
            ->discoverPages(in: app_path('Filament/Pages'), for: 'App\\Filament\\Pages')
            ->pages([
                Pages\Dashboard::class,
            ])
            ->discoverWidgets(in: app_path('Filament/Widgets'), for: 'App\\Filament\\Widgets')
            ->widgets([
                Widgets\AccountWidget::class,
                Widgets\FilamentInfoWidget::class,
            ])
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                VerifyCsrfToken::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([
                Authenticate::class,
            ])
            ->tenantRegistration(RegisterTeam::class)
            ->tenant(
                model : Team::class,
                ownershipRelationship: 'team',
                slugAttribute: 'slug'
            );
        //    ->tenantRoutePrefix('team');

        //     ->userMenuItems([
        //     MenuItem::make()
        //         ->label('Settings')
        //         //  ->url(fn (): string => Settings::getUrl())
        //         // ->url(UserResource::getUrl())
        //         ->icon('heroicon-o-cog-6-tooth'),
        // ])
        // ->userMenuItems([
        //     'profile' => MenuItem::make()->label('Edit profile'),
        //     // ... di Filamen 3 belum tahu caranya, maka diganti di function boot dibawah
        // ]);
    }

    public function boot(): void
    {

        Filament::serving(function () {
            Filament::registerUserMenuItems([
                UserMenuItem::make()
                    ->label('Settings')
                    // ->url(UserResource::getUrl())
                    ->icon('heroicon-s-cog'),
                // ...
            ]);
        });

    }
}
